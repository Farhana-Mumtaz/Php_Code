
<?php
require "connect.php";
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Crud Operation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" type="text/css" rel="stylesheet">
</head>
   <body>
    <div class="container my-5">
      <div class="row">
        <div class="col-lg-8">
          <h2 class=" my-5">Students Details</h2>
        </div>

        <div class="col-lg-4">
          <a href="user.php" class="btn btn-info btn-lg my-5">
          <span class="glyphicon glyphicon-plus"></span>Add New Students
        </a>
         </div>

         </div>
  <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email</th>
      <th scope="col">Operation</th>
    </tr>
  </thead>

  <tbody>
    <?php
$sql="Select *from `crud`";
$result=mysqli_query($conn,$sql);
if($result){

while($row=mysqli_fetch_assoc($result))
{
  $id=$row['id'];
  $name=$row['First_Name'];
  $lname=$row['Last_Name'];
  $email=$row['Email'];
  echo '
  <tr>
<th scope="row">'.$id.'</th>
<td>'.$name.'</td>
<td>'.$lname.'</td>
<td>'.$email.'</td>
 <td>
    <button class="btn btn-default"><a href="" ><span class=" glyphicon glyphicon-eye-open"></span> </a></button>

   <button class="btn btn-primary"><a href="update.php? updateid='.$id.'" class="text-light"><span class=" glyphicon glyphicon-pencil"></span> </a></button>
    <button class="btn btn-danger"><a href="delete.php? deleteid='.$id.'" class="text-light"><span class=" glyphicon glyphicon-trash"></span> </a></button>


 </td>
 </tr> ';


}

}
    ?>
  
  </tbody>
</table>
  </div>
   </body>
   </html>
 

  <!--  $row=mysqli_fetch_assoc($result);
  echo $row['First_Name'];
  echo $row['Last_Name'];
  use while becoz there may be thousands of records in my table all the time i need to fetch one by one so instead of fetching one by one use while loop -->