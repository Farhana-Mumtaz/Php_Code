<!DOCTYPE html>
<html>
<head>
	<title></title>
	  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" type="text/css" rel="stylesheet">
</head>
<body>
<?php
require "connect.php";
if(isset($_GET['deleteid']))
{
	$id=$_GET['deleteid'];
	$sql="delete from `crud` where id=$id";
	$result=mysqli_query($conn,$sql);
	if($result)
	{
header('location:display.php');
	}
	else
	{
		die(mysqli_error($conn));
	}
}

?>
</body>
</html>

