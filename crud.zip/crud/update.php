<?php
include "connect.php";

$id=$_GET['updateid'];
$sql="select *from `crud` where id=$id";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
$name=$row['First_Name'];
$lname=$row['Last_Name'];
$email=$row['Email'];
if(isset($_POST['update']))
{
  $name=$_POST['firstname'];
  $lname=$_POST['lastname'];
  $email=$_POST['email'];

  $sql="update  `crud` set id=$id,First_Name='$name',Last_Name='$lname',Email='$email'
where id=$id";
  $result=mysqli_query($conn,$sql);
  if($result)
  {
  	// echo "updated successfully";
    header('location:display.php');
  }
  else
  {
    die(mysqli_error($conn));
  }
}
?>


<!DOCTYPE html>
<html>
  <head>
    <title>Crud Operation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script> 
   <body>
    <div class="container m-5">
     
        <form method="post" autocomplete="off">
           <div class="form-group">
           <label>First Name</label>
           <input type="text" class="form-control"  autocomplete="off"  name="firstname"placeholder="Enter First Name" value=<?php echo $name?> >
               </div>
                 <div class="form-group">
           <label>Last Name</label>
           <input type="text" class="form-control" name="lastname" placeholder="Enter Last Name" autocomplete="off" value=<?php echo $lname?> >
               </div>
                 <div class="form-group">
           <label>Email ID</label>
           <input type="email" class="form-control" name="email" placeholder="Enter Email" autocomplete="off" value=<?php echo $email?> >
           
               </div>
               <button type="submit" name="update" class="btn btn-primary" >Update</button>
        </form>
   
    </div>
   
  </body>

</html>